C - Bit manipulation
