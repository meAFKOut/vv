C - Doubly linked lists
