C - function pointers
