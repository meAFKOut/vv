#include "main.h"
/**
 * add - check lowercase.
 * @a: variable1
 * @b: variable2
 * Return: result of addition
 */
int add(int a, int b)
{
	return (a + b);
}
