#include "main.h"
/**
 *_abs - absolute value.
 *@x: variable
 *Return: absolute value
 */
int _abs(int x)
{
	if (x < 0)
	{
		x = x * -1;
	}
	return (x);
}
