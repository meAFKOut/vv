C - malloc, free
