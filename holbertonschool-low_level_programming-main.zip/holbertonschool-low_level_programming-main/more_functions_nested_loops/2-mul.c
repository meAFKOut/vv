#include "main.h"
/**
 * mul - a function that multiplies two integers.
 * @a: Variable
 * @b: Variable
 * Return: multiplies two integers.
 */
int mul(int a, int b)
{
	return (a * b);
}
