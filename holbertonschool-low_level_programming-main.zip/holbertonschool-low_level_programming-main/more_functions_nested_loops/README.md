C - More functions, more nested loops
