C - More malloc, free
