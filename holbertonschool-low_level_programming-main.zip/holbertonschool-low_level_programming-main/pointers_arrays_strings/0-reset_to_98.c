#include "main.h"

/**
 * reset_to_98 - resets to 98
 * @n: num
 *
 * Return: just a return
 */
void reset_to_98(int *n)
{
	*n = 98;
}
