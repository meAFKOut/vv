C - Pointers, arrays and strings
