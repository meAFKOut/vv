C - Recursion
