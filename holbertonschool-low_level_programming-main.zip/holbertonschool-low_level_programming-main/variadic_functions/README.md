C - variadic functions
